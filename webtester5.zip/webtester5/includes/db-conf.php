<?php
// Place your mysql hostname here (usually localhost)
define ("SQL_HOST","localhost");
// Place your mysql username here
define ("SQL_USER","username");
// Place your mysql password here
define ("SQL_PASS","password");
// Place your mysql database name here
define ("SQL_DB","database_name");
// Database type
define ("SQL_TYPE", "sqlite");
// SQLite database path
define ("SQLITE_DB", "./db.sqlite");
?>