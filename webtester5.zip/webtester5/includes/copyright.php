<span class="style1">Copyright &copy; 2003 - 2010 Eppler Software<br>
            <font size="-2">Page created in 
            <?php include "./includes/timerfoot.php" ?>
seconds - v5.1.20101016</font>
           </span>
